#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "ui_mainwindow.h"
#include <QtCharts>
#include <QMainWindow>
#include <QApplication>
#include <QLocale>
#include <QTranslator>
#include <QTextCharFormat>
#include <QTextEdit>
#include <QTextFormat>
#include <QVBoxLayout>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_pushButton_clicked();

    void on_textBrowser_2_currentCharFormatChanged(const QTextCharFormat &format);

    void on_textEdit_currentCharFormatChanged(const QTextCharFormat &format);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
