#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtCharts>
#include <QMap>
#include <QVector>
#include <QPair>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QDebug>
#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QDir>
#include <QStandardPaths>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QBarSeries>
#include <QtCharts/QPieSeries>
#include <QVBoxLayout>
#include <QPen>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("蒙特卡洛作业2_概率统计");
    QFont font("Times New Roman", 16); // 字体 "Times New Roman"，大小 16
    ui->textEdit->setFont(font);
    ui->textBrowser_2->setFont(font);
}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::on_textBrowser_2_currentCharFormatChanged(const QTextCharFormat &format)
{

}


void MainWindow::on_textEdit_currentCharFormatChanged(const QTextCharFormat &format)
{

}

void MainWindow::on_pushButton_clicked()
{
    // 获取 QTextEdit 中的文本内容
    QString inputText = ui->textEdit->toPlainText();

    // 创建一个字母频率的字典（忽略大小写）
    QMap<QChar, int> letterCount;

    // 统计字母的频率
    int totalLetters = 0;
    for (int i = 0; i < inputText.length(); ++i) {
        QChar ch = inputText[i];

        // 只统计字母字符，不区分大小写
        if (ch.isLetter()) {
            ch = ch.toLower();  // 转换为小写字母
            letterCount[ch]++;  // 统计字母频率
            totalLetters++;     // 统计总字母数
        }
    }

    // 计算字母出现的概率（以百分比表示）
    QMap<QChar, double> letterProbabilities;
    for (auto it = letterCount.begin(); it != letterCount.end(); ++it) {
        // 计算百分比
        letterProbabilities[it.key()] = (double)it.value() / totalLetters * 100;
    }

    // 将概率和字母存储到 QVector 中，并按概率从大到小排序
    QVector<QPair<QChar, double>> sortedProbabilities;
    for (auto it = letterProbabilities.begin(); it != letterProbabilities.end(); ++it) {
        sortedProbabilities.append(qMakePair(it.key(), it.value()));
    }

    // 按照概率从大到小排序
    std::sort(sortedProbabilities.begin(), sortedProbabilities.end(),
              [](const QPair<QChar, double>& a, const QPair<QChar, double>& b) {
                  return a.second > b.second;  // 按照概率值排序
              });

    // 获取文件路径（默认保存到桌面，或者让用户选择保存位置）
    QString outputFilePath;

    // 让用户选择文件路径（如果没有指定路径）
    outputFilePath = QFileDialog::getSaveFileName(this, "Save File",
                                                  QStandardPaths::writableLocation(QStandardPaths::DesktopLocation) + "/letter_probabilities.txt",
                                                  "Text Files (*.txt);;All Files (*)");

    if (outputFilePath.isEmpty()) {
        // 如果用户没有选择路径，使用默认路径（桌面）
        outputFilePath = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation) + "/letter_probabilities.txt";
    }

    // 打开文件进行写入
    QFile outputFile(outputFilePath);
    if (!outputFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file:" << outputFilePath << "Error:" << outputFile.errorString();
        return;  // 提前返回以避免后续操作
    }

    // 写入数据
    QTextStream out(&outputFile);
    out << "字母出现概率 (按百分比计，排序从高到低):\n";
    for (const auto& pair : sortedProbabilities) {
        out << pair.first << ": " << QString::number(pair.second, 'f', 2) << "%\n";
    }
    out.flush();  // 强制刷新缓冲区
    outputFile.close();
    qDebug() << "File written successfully to:" << outputFilePath;

    // 输出到控制台（可选）
    for (const auto& pair : sortedProbabilities) {
        qDebug() << pair.first << ": " << pair.second << "%";
    }

    // 将排序后的结果放入 QString 并显示
    QString result;
    for (const auto& pair : sortedProbabilities) {
        result += QString("%1: %2%\n").arg(pair.first).arg(pair.second, 0, 'f', 2);  // 使用百分比显示
    }

    // 创建 QStandardItemModel 并将每一行添加为项
    QStandardItemModel* model = new QStandardItemModel();

    // 分割 result 字符串并将每一行添加为一个 QListView 项
    QStringList resultLines = result.split("\n");
    for (const QString& line : resultLines) {
        if (!line.isEmpty()) {
            QStandardItem* item = new QStandardItem(line);
            model->appendRow(item);  // 将每行文本作为单独的项添加到模型
        }
    }

    // 提取 QStandardItemModel 中的文本内容并将其设置为 QTextBrowser 的 HTML 格式
    QString htmlContent;
    for (int row = 0; row < model->rowCount(); ++row) {
        QStandardItem* item = model->item(row);
        htmlContent += "<p>" + item->text() + "</p>";
    }

    // 将 HTML 内容设置给 QTextBrowser
    ui->textBrowser_2->setHtml(htmlContent);

    // 创建 QBarSeries，并将每个字母的概率作为柱状图的部分
    QBarSeries *series = new QBarSeries();

    // 创建 QBarSet 来存储每个字母的概率
    QBarSet *set = new QBarSet("");

    double maxValue = 0;  // 用于找出最大值
    for (const auto& pair : sortedProbabilities) {
        *set << pair.second;  // 将每个字母的概率加入到 QBarSet
        if (pair.second > maxValue) {
            maxValue = pair.second;  // 更新最大值
        }
    }

    series->append(set);

    // 创建 QChart 并添加柱状图
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("字母出现频率柱状图");

    // 设置 X 轴标签
    QStringList categories;
    for (const auto& pair : sortedProbabilities) {
        categories << QString(pair.first);  // 使用字母作为 X 轴标签
    }

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->setAxisX(axisX, series);

    // 设置 Y 轴，并根据最大值调整范围
    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, maxValue);  // 设置 Y 轴上限为最大值的 110%
    chart->setAxisY(axisY, series);

    // 设置字体大小为 18
    QFont font = axisX->labelsFont();
    font.setPointSize(18);
    axisX->setLabelsFont(font);
    axisY->setLabelsFont(font);

    // 设置标题字体大小为 18
    chart->setTitleFont(font);

    // 设置柱状图样式
    for (int i = 0; i < series->count(); ++i) {
        QBarSet *set = series->barSets().at(i);
        set->setLabelColor(Qt::black);
        set->setLabelFont(font);  // 设置柱状图的标签字体
    }

    // 显示图表
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    chartView->resize(600, 400);  // 调整图表的大小
    chartView->setWindowTitle("柱状统计图");
    chartView->show();
}


